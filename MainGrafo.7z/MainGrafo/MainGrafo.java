package grafo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

public class MainGrafo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o número de vértices do grafo: ");
        int numVertices = sc.nextInt();
        int sumArestas = 0;
        int grauMin = -1;
        int grauMax = 0;
        int[][] grafo = new int[numVertices + 1][numVertices + 1];
        for (int i = 0; i < numVertices; i++) {
            System.out.println("Digite o número de arestas para o vértice " + (i + 1) + ": ");
            int numArestas = sc.nextInt();
            for (int j = 0; j < numArestas; j++) {
                System.out.println("Digite o vértice conectado à aresta " + (j + 1) + " do vértice " + (i + 1) + ": ");
                int verticeConectado = sc.nextInt() - 1;
                grafo[i][verticeConectado] = 1;
                grafo[verticeConectado][i] = 1;
            }

            if (grauMin == -1 || grauMin > numArestas) {
                grauMin = numArestas;
            }
            if (grauMax < numArestas) {
                grauMax = numArestas;
            }

            sumArestas += numArestas;

        }
        System.out.println("A matriz representativa do grafo é:");
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                System.out.print(grafo[i][j] + " ");
            }
            System.out.println();

        }

        System.out.println("O número de vértices é: " + numVertices);
        System.out.println("O número de arestas é: " + sumArestas);
        System.out.println("O grau mínimo é: " + grauMin);
        System.out.println("O grau máximo é: " + grauMax);

        findCC(grafo);
        bfs(grafo, 0);
    }

    public static void bfs(int[][] matrix, int start) {
        if (matrix.length == 0 || start < 0 || start >= matrix.length) {
            System.out.println("Matrix de adjacência vazia ou inválida!");
        }

        List<Integer> result = new ArrayList<>();
        Queue<Integer> queue = new LinkedList<>();
        boolean[] visited = new boolean[matrix.length];

        queue.offer(start);
        visited[start] = true;

        while (!queue.isEmpty()) {
            int vertex = queue.poll();

            result.add(vertex + 1);

            List<Integer> neighbors = new ArrayList<>();
            for (int i = 0; i < matrix[vertex].length; i++) {
                if (matrix[vertex][i] == 1 && !visited[i]) {
                    neighbors.add(i);
                    visited[i] = true;
                }
            }

            for (int neighbor : neighbors) {
                queue.offer(neighbor);
            }
        }

        System.out.println("Resultado da busca em largura: " + result);;
    }

    private static void findCC(int[][] matrix) {
        boolean[] visitados = new boolean[matrix.length];

        System.out.println("Componentes conexos:");

        for (int i = 0; i < matrix.length; i++) {
            if (!visitados[i]) {
                Queue<Integer> queue = new LinkedList<>();
                visitados[i] = true;
                queue.add(i);

                System.out.print("[ ");
                while (!queue.isEmpty()) {
                    int atual = queue.poll();
                    System.out.print((atual + 1) + " ");
                    System.out.println(atual);

                    for (int j = 0; j < matrix.length; j++) {
                        if (matrix[atual][j] == 1 && !visitados[j]) {
                            visitados[j] = true;
                            queue.add(j);
                        }
                    }
                }
                System.out.print("]");
                System.out.println();
            }
        }
    }
}
